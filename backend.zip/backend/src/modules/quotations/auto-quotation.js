// Create an accepted price snapshot ONLY when the technician never quoted.
// The customer already accepted these booked service prices when placing the booking.
export async function ensureDefaultQuotation(db, bookingId, technicianId) {
  const existing = await db.query('SELECT id FROM quotations WHERE booking_id=$1 LIMIT 1', [bookingId])
  if (existing.rowCount) return false
  const services = (await db.query(`SELECT bus.id,bus.service_id,bus.unit_price,s.name
    FROM booking_unit_services bus JOIN booking_units bu ON bu.id=bus.booking_unit_id
    JOIN services s ON s.id=bus.service_id WHERE bu.booking_id=$1 ORDER BY bus.id`, [bookingId])).rows
  const subtotal = services.reduce((sum, s) => sum + Number(s.unit_price), 0)
  const booking = (await db.query('SELECT subtotal FROM bookings WHERE id=$1', [bookingId])).rows[0]
  // Fail closed: do not silently replace existing booking prices or invent missing services.
  if (!services.length || Math.abs(subtotal - Number(booking.subtotal)) > 0.009) {
    const error = new Error('Default service prices do not match booking subtotal; manual quotation is required.')
    error.status = 409
    throw error
  }
  const quote = (await db.query(`INSERT INTO quotations
    (booking_id,technician_id,quotation_number,quotation_type,labor_amount,parts_amount,subtotal,discount_amount,total_amount,status,note,responded_at)
    VALUES($1,$2,1,'INITIAL',$3,0,$3,0,$3,'ACCEPTED','AUTO_BOOKING_PRICE',CURRENT_TIMESTAMP)
    RETURNING id`, [bookingId,technicianId,subtotal])).rows[0]
  for (const s of services) {
    await db.query(`INSERT INTO quotation_items
      (quotation_id,booking_unit_service_id,item_type,service_id,description,quantity,unit,unit_price,total_price,discount_amount)
      VALUES($1,$2,'SERVICE',$3,$4,1,'lần',$5,$5,0)`, [quote.id,s.id,s.service_id,s.name,s.unit_price])
  }
  await db.query('SELECT (refresh_booking_pricing($1,NULL)).id', [bookingId])
  return true
}
